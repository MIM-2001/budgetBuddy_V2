import { existsSync, mkdirSync, readFileSync, writeFileSync, renameSync } from 'node:fs';
import { dirname } from 'node:path';
import { Account, Transaction, BudgetCategory } from './account.js';
import { FinancialCalendar, RecurringItem } from './calendar.js';

export class Storage {
  constructor(file) {
    this.file = file;
  }

  load(today) {
    if (!existsSync(this.file)) return { account: new Account(today), calendar: new FinancialCalendar() };
    const data = JSON.parse(readFileSync(this.file, 'utf8'));
    if (data.version !== 1 || !Array.isArray(data.account?.transactions) || !Array.isArray(data.rules)) {
      throw new Error('Unrecognized data file. It has not been overwritten.');
    }
    const account = new Account(data.account.historyStart);
    account.setupComplete = data.account.setupComplete;
    account.setupStage = data.account.setupStage || (account.setupComplete ? 'complete' : 'income');
    for (const category of data.account.categories) {
      account.categories.push(new BudgetCategory(category.name, category.amount,
        category.flexible, category.createdAt, category.id));
    }
    for (const transaction of data.account.transactions) {
      const item = new Transaction(transaction);
      if (item.type === 'expense') account.getCategory(item.categoryId);
      account.transactions.push(item);
    }
    account.deletedOccurrences = data.account.deletedOccurrences;
    account.challengeResponses = data.account.challengeResponses;
    if (!Array.isArray(account.deletedOccurrences) || !Array.isArray(account.challengeResponses)) {
      throw new Error('Invalid saved history. It has not been overwritten.');
    }
    const calendar = new FinancialCalendar();
    for (const details of data.rules) {
      const rule = new RecurringItem(details);
      if (rule.type === 'expense') account.getCategory(rule.categoryId);
      calendar.rules.push(rule);
    }
    return { account, calendar };
  }

  save(account, calendar) {
    mkdirSync(dirname(this.file), { recursive: true });
    const data = { version: 1, account, rules: calendar.rules };
    writeFileSync(this.file + '.tmp', JSON.stringify(data, null, 2) + '\n', { mode: 0o600 });
    renameSync(this.file + '.tmp', this.file);
  }
}
