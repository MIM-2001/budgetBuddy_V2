import { createInterface } from 'node:readline';
import { fileURLToPath } from 'node:url';
import { Storage } from './storage.js';
import { ServiceHub } from './service-hub.js';
import { today } from './helpers.js';
import { TerminalView, TransactionView, BudgetView, CalendarView,
  AffordabilityView, ChallengesView } from './views.js';
import { AppController, TransactionController, BudgetController, CalendarController,
  AffordabilityController, ChallengesController } from './controllers.js';

// Create and connect the objects here. There is no budgeting logic in main.js.
const reader = createInterface({ input: process.stdin, output: process.stdout });
try {
  const path = process.env.BUDGETBUDDY_DATA || fileURLToPath(new URL('./data/budget.json', import.meta.url));
  const storage = new Storage(path);
  const loaded = storage.load(today());
  const serviceHub = new ServiceHub(loaded.account, loaded.calendar, storage);
  const terminal = new TerminalView(reader);

  const transactionView = new TransactionView(terminal);
  const transactionController = new TransactionController(transactionView, serviceHub);
  const budgetController = new BudgetController(new BudgetView(terminal), serviceHub);
  const calendarController = new CalendarController(new CalendarView(terminal), serviceHub, transactionController);
  const affordabilityController = new AffordabilityController(new AffordabilityView(terminal), serviceHub);
  const challengesController = new ChallengesController(new ChallengesView(terminal), serviceHub);

  const app = new AppController(terminal, serviceHub, transactionController,
    budgetController, calendarController, affordabilityController, challengesController);
  terminal.print('Data file: ' + path);
  await app.run();
} catch (error) {
  if (error.message === 'Input closed.') console.log('\nInput closed. Run bash run.command to continue.');
  else { console.error('BudgetBuddy stopped: ' + error.message); process.exitCode = 1; }
} finally { reader.close(); }
