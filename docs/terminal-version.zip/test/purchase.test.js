import test from 'node:test';
import assert from 'node:assert/strict';
import { mkdtempSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { Account } from '../account.js';
import { FinancialCalendar } from '../calendar.js';
import { Storage } from '../storage.js';
import { ServiceHub } from '../service-hub.js';
import { today } from '../helpers.js';

const cases = [
  { name: 'record checked purchase using its selected category and price',
    input: '5\n200\n1\ny\nShoes\n2\n3\n0\n', amount: 20000, message: /Expense recorded/ },
  { name: 'Any category asks for a required expense category before saving',
    input: '5\n200\n0\ny\n1\nShoes\n0\n', amount: 20000, message: /Expense recorded/ },
  { name: 'declining leaves the check read-only',
    input: '5\n200\n1\nn\n0\n', amount: 0, message: /Yes, you can afford it/ },
  { name: 'cancelling required category does not record a purchase',
    input: '5\n200\n0\ny\n0\n0\n', amount: 0, message: /Purchase not recorded/ },
  { name: 'an actual purchase can be recorded even after a Not yet result',
    input: '5\n1000\n1\ny\nShoes\n0\n', amount: 100000, message: /Not yet/ }
];

for (const scenario of cases) {
  test(scenario.name, () => {
    const folder = mkdtempSync(join(tmpdir(), 'budgetbuddy-purchase-'));
    try {
      const storage = new Storage(join(folder, 'budget.json'));
      const account = new Account(today());
      account.setupComplete = true;
      account.setupStage = 'complete';
      const category = account.addCategory('Wants', 50000, true, today());
      account.addTransaction({ type: 'income', name: 'Income', amount: 100000, date: today() }, today());
      storage.save(account, new FinancialCalendar());
      const result = spawnSync(process.execPath, [fileURLToPath(new URL('../main.js', import.meta.url))], {
        input: scenario.input, encoding: 'utf8', env: { ...process.env, BUDGETBUDDY_DATA: storage.file }
      });
      assert.equal(result.status, 0, result.stdout + result.stderr);
      assert.match(result.stdout, /Record this purchase as an expense for today/);
      assert.match(result.stdout, scenario.message);
      assert.match(result.stdout, /Saved\. Goodbye!/);
      const loaded = storage.load(today());
      const expenses = loaded.account.transactions.filter(t => t.type === 'expense');
      assert.equal(expenses.length, scenario.amount ? 1 : 0);
      if (scenario.amount) {
        assert.equal(expenses[0].name, 'Shoes');
        assert.equal(expenses[0].amount, scenario.amount);
        assert.equal(expenses[0].categoryId, category.id);
        assert.equal(expenses[0].date, today());
        assert.equal(expenses[0].recurringId, '');
      }
      assert.equal(loaded.calendar.rules.length, 0);
      const hub = new ServiceHub(loaded.account, loaded.calendar);
      assert.equal(hub.getDashboard(today()).spent, scenario.amount);
      assert.equal(hub.getDashboard(today()).safe, Math.max(0, 90000 - scenario.amount));
    } finally { rmSync(folder, { recursive: true }); }
  });
}
