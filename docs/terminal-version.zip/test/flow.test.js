import test from 'node:test';
import assert from 'node:assert/strict';
import { Account } from '../account.js';
import { FinancialCalendar } from '../calendar.js';
import { ServiceHub } from '../service-hub.js';
import { AffordabilityController } from '../controllers.js';
import { AffordabilityView } from '../views.js';

test('purchase travels through controller, hub and services before view receives result', async () => {
  const account = new Account('2026-11-24');
  const calendar = new FinancialCalendar();
  account.addCategory('Wants', 50000, true, '2026-11-24');
  account.addTransaction({ type: 'income', name: 'Income', amount: 100000,
    date: '2026-11-01' }, '2026-11-24');
  const hub = new ServiceHub(account, calendar);
  const calls = [];
  // Instrument real services so this test detects bypassing the required layers.
  for (const [object, method, label] of [
    [hub, 'canAfford', 'hub'],
    [hub.affordabilityService, 'evaluatePurchase', 'affordability'],
    [hub.spendingService, 'summary', 'spending'],
    [hub.recurringService, 'unpaidTotal', 'recurring']
  ]) {
    const original = object[method].bind(object);
    object[method] = (...args) => { calls.push(label); return original(...args); };
  }
  let displayed;
  const view = {
    async readInput(categories) {
      assert.equal(categories[0].name, 'Wants');
      calls.push('read input');
      return { price: 10000, categoryId: '' };
    },
    showResult(result) { calls.push('show result'); displayed = result; },
    async readExpenseInput() { return null; }
  };
  const controller = new AffordabilityController(view, hub);
  const result = await controller.handleCheckClicked('2026-11-24');
  assert.equal(result.answer, 'yes');
  assert.equal(displayed, result);
  assert.deepEqual(calls, ['read input', 'hub', 'affordability', 'spending', 'recurring', 'show result']);
  assert.equal(account.transactions.length, 1); // A check must not save a purchase.
});

test('real AffordabilityView handles terminal input and output without model access', async () => {
  const output = [];
  const terminal = {
    print(message) { output.push(message); },
    async amount() { return 10000; },
    async select() { return null; }
  };
  const view = new AffordabilityView(terminal);
  assert.deepEqual(await view.readInput([]), { price: 10000, categoryId: '' });
  view.showResult({ answer: 'no', reason: '', price: 10000,
    shortfall: 6000, weeklySaving4: 1500, weeklySaving8: 750,
    numbers: { left: 5000, bills: 0, buffer: 1000, safe: 4000 } });
  assert.ok(output.some(line => line.includes('$60.00 short')));
  assert.equal('account' in view, false);
  assert.equal('calendar' in view, false);
});

test('dashboard keeps the warning when category budgets exceed estimated income', () => {
  const account = new Account('2026-11-24');
  account.addCategory('Wants', 50000, true, '2026-11-24');
  const hub = new ServiceHub(account, new FinancialCalendar());
  assert.equal(hub.getDashboard('2026-11-24').overAllocated, true);
});
