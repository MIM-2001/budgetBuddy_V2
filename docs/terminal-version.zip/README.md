# BudgetBuddy JavaScript — Version 2: explicit flow

This is a **separate terminal project**. BudgetBuddy-JS is Version 1 and was not
edited to make this version. This folder also uses its own data/budget.json;
Version 1's financial data is not copied or loaded automatically.

## Run

Open this folder in VS Code and run:

```bash
bash run.command
```

With Node.js 20+ on your PATH, `node main.js` also works. No npm/dependencies are
required. On this Mac, run.command can fall back to ChatGPT's bundled Node.

Run all checks:

```bash
bash run.command --test
```

## The purchase flow, step by step

1. User selects **5. Affordability** in the terminal.
2. AppController calls AffordabilityController.handleCheckClicked().
3. The controller asks AffordabilityView.readInput() for price and optional category.
4. The controller calls ServiceHub.canAfford(price, categoryId, date).
5. ServiceHub calls AffordabilityService.evaluatePurchase().
6. AffordabilityService calls SpendingService.summary() and RecurringService.unpaidTotal().
7. SpendingService uses MonthlyIncomeCalculator and MonthlyExpenseCalculator to
   read the account's monthly records/estimates. The calculators reuse model query
   methods from Version 1, so this refactor does not change the financial math.
8. RecurringService asks the imported FinancialCalendar for upcoming bills.
9. AffordabilityService applies the existing conditions. When relevant, it calls
   SpendingService.budgetRemaining() for the optional category check.
10. The result returns through ServiceHub to the controller.
11. The controller calls AffordabilityView.showResult(result).
12. The view asks whether to record the actual purchase. If the user says yes,
    it collects a description and a required category (reusing the checked
    category when selected). The controller calls ServiceHub.saveTransaction()
    with the checked price, today's date, and type expense. The hub saves a
    one-time transaction through Account and Storage, then the view confirms it.

```text
AffordabilityView.readInput()
          |
AffordabilityController.handleCheckClicked()
          |
ServiceHub.canAfford()
          |
AffordabilityService.evaluatePurchase()
          |                         |
SpendingService                 RecurringService
    |                               |
Monthly calculators             FinancialCalendar
    |                               |
    +------- domain objects --------+
          |
result -> ServiceHub -> Controller -> AffordabilityView.showResult()
```

The controller reads input through the view; the view does not directly call the
services. The service returns data and never prints. Only the view formats and
displays the answer. The tests exercise this actual route, including returning
the same result object to the view. A check remains read-only unless the user
chooses to record the purchase afterward. Denying or cancelling does not add it.

## What each file does

| File | Main classes and responsibility |
| --- | --- |
| main.js | Creates and connects the objects, loads data, and starts the application |
| views.js | TerminalView plus TransactionView, BudgetView, CalendarView, AffordabilityView, ChallengesView; input/output only |
| controllers.js | AppController and each feature's controller; coordinate views and ServiceHub |
| service-hub.js | ServiceHub facade; the shared entry point for controller requests |
| services.js | MonthlyIncomeCalculator, MonthlyExpenseCalculator, SpendingService, RecurringService, AffordabilityService |
| challenges.js | ChallengesService; spending-based budget recommendations and accept/deny logic |
| account.js | Account, Transaction, BudgetCategory; own financial records and model query methods |
| calendar.js | FinancialCalendar and RecurringItem; schedule rules and due occurrences |
| storage.js | Storage; saves JSON and reconstructs class instances |
| helpers.js | Shared date operations, amount validation, and display formatting |
| run.command | Runs the program or tests with available Node.js |
| test/ | Regression checks for financial behavior, terminal workflows, and layered flow |
| docs/plan.md | Scope and progress of the separate-version refactor |
| docs/version1-checksums.json | SHA256 baseline used to verify Version 1 was preserved |

The controllers for other menus also call ServiceHub instead of directly reaching
into Account, FinancialCalendar, Storage, or individual feature services. Views
receive simple display data and contain no Account/calendar references.

This matches the requested View/Controller/facade/service route. The larger old
diagram's separate DAOs, Google Drive, profile/sign-in, and visual calendar are
not implemented in this terminal starter. Persistence remains one Storage class
and a local JSON file; it is not claimed to implement every diagram box.

## Features retained

- Setup collects recurring income, creates editable 50/30/20 starter budgets,
  and collects recurring expenses. Amounts are per payment; dates are YYYY-MM-DD.
- Transactions offers add/list/delete and asks whether each addition repeats.
- Recurring Items offers add, stop, and future amount changes. Stopping preserves
  history. To change frequency/dates, stop the rule and add its replacement from
  the next unpaid date, avoiding duplicate historical payments.
- Monthly, every-14-day, and selected-monthly-day schedules record automatically
  on startup/main-menu refresh and catch up after the program was closed.
- Completed setup entries survive interruptions. Occurrences use stable IDs;
  deleting one does not recreate it or stop the whole schedule.
- Affordability and Challenges remain separate user-opened menus. After any
  affordability result, including Tight or Not yet, the user can optionally
  record a purchase that actually happened. This records history; it does not
  override the original affordability decision. Future checks use the new expense.

## Financial rules retained

All money is integer cents internally. Budgets use calendar months.

```text
safe = max(0, estimated monthly income - recorded monthly spending
           - upcoming monthly expenses - 10% income buffer)
```

Price above safe returns No; at least 80% of safe returns Tight; above a selected
category's remaining budget returns Tight; otherwise Yes. Checking does not record
a purchase unless the user chooses the separate recording option afterward.
It remains a monthly estimate, not a current bank balance.

Active recurring income is normalized: monthly amount, biweekly amount x 26 / 12,
or amount x selected days per month. Those deposits are not added again as income.
One-time current-month income is added. For stopped income rules, actual deposits
this month count instead. Upcoming bills stop being reserved once recorded as
expenses, preventing double subtraction.

Starter percentages are editable targets. The Savings category does not change
the original affordability formula: it reserves a 10% buffer, not the full 20%
savings allocation. Automatic records assume scheduled payments happened; no bank
verification or financial transfer occurs.

Challenges require 28 elapsed days for the account and category. Recommendations
use last-28-day spending / 28 x days in this month, compared to the monthly budget.
Only flexible categories with positive spending qualify. Wants is flexible by
default; Needs and Savings are protected. Accept updates the budget; deny saves
the response for the same category/month/current-budget/recommended-amount.
There are no seven-day competitions, levels, countdowns, wins, or losses.

Monthly dates preserve their anchor through short months (January 31 -> February
28/29 -> March 31). Selected-day rules allow at most one day from 28–31 so two
payments cannot silently collapse onto the same February date. Dates use
1900–2100. Future one-time actual transactions are not supported; future recurring
rules are. Run one process per data file. Invalid saved data stops loading rather
than overwriting the file.

For an isolated demo:

```bash
BUDGETBUDDY_DATA=/tmp/budgetbuddy-v2-demo.json bash run.command
```
