import { today } from './helpers.js';

// Controllers coordinate views and the facade; they do not calculate budgets.
export class AffordabilityController {
  constructor(view, serviceHub) {
    this.view = view;
    this.serviceHub = serviceHub;
  }

  async handleCheckClicked(date) {
    const categories = this.serviceHub.getBudgets(date);
    const input = await this.view.readInput(categories);
    const result = this.serviceHub.canAfford(input.price, input.categoryId, date);
    this.view.showResult(result);
    const purchase = await this.view.readExpenseInput(input, categories);
    if (purchase) {
      const expense = { type: 'expense', name: purchase.name, amount: input.price,
        date, categoryId: purchase.categoryId, repeating: false };
      this.serviceHub.saveTransaction(expense, date);
      this.view.showExpenseSaved(expense);
    }
    return result;
  }
}

export class TransactionController {
  constructor(view, serviceHub) {
    this.view = view;
    this.serviceHub = serviceHub;
  }

  async handleSave(date, type = '', repeating = false) {
    const categories = this.serviceHub.getBudgets(date);
    const input = await this.view.readInput(categories, type, repeating);
    const result = this.serviceHub.saveTransaction(input, date);
    this.view.showSaved(result);
  }

  async open(date) {
    const action = await this.view.readAction();
    if (action === '1') await this.handleSave(date);
    if (action === '3') this.view.showList(this.serviceHub.getTransactions());
    if (action === '2') {
      const item = await this.view.selectTransaction(this.serviceHub.getTransactions());
      if (item) {
        this.serviceHub.deleteTransaction(item.id);
        this.view.terminal.print('Deleted this entry. Any recurring rule still continues; stop it under Recurring Items.');
      }
    }
  }
}

export class BudgetController {
  constructor(view, serviceHub) {
    this.view = view;
    this.serviceHub = serviceHub;
  }

  render(date) {
    this.view.render(this.serviceHub.getBudgets(date));
  }

  async open(date) {
    const input = await this.view.readInput(this.serviceHub.getBudgets(date));
    if (input) this.serviceHub.saveBudget(input, date);
  }
}

export class CalendarController {
  constructor(view, serviceHub, transactionController) {
    this.view = view;
    this.serviceHub = serviceHub;
    this.transactionController = transactionController;
  }

  async open(date) {
    const items = this.serviceHub.getRecurringItems();
    const action = await this.view.readAction(items);
    if (action === '1') await this.transactionController.handleSave(date, '', true);
    if (action === '2' || action === '3') {
      const item = await this.view.selectRule(items);
      if (!item) return;
      if (action === '2') this.serviceHub.stopRecurring(item.id);
      else {
        const amount = await this.view.terminal.amount('New amount per payment');
        this.serviceHub.changeRecurringAmount(item.id, amount);
      }
      this.view.terminal.print('Recurring item updated. Earlier transactions were kept.');
    }
  }
}

export class ChallengesController {
  constructor(view, serviceHub) {
    this.view = view;
    this.serviceHub = serviceHub;
  }

  async open(date) {
    const input = await this.view.readInput(this.serviceHub.getChallenges(date));
    if (input) {
      this.serviceHub.respondToChallenge(input.idea, input.accept, date);
      this.view.showResult(input.accept);
    }
  }
}

export class AppController {
  constructor(terminal, serviceHub, transactions, budgets, recurring, affordability, challenges) {
    this.terminal = terminal;
    this.serviceHub = serviceHub;
    this.transactions = transactions;
    this.budgets = budgets;
    this.recurring = recurring;
    this.affordability = affordability;
    this.challenges = challenges;
  }

  showError(error) {
    // EOF ends the session. Disk errors are fatal rather than pretending to save.
    if (error.message === 'Input closed.' || error.code) throw error;
    this.terminal.print('Could not complete that action: ' + error.message);
  }

  async setup(date) {
    this.terminal.print('\nFIRST-TIME SETUP\nEnter amounts per payment, using take-home income.');
    if (this.serviceHub.setupState().stage === 'income') {
      while (await this.terminal.yes('Add a regular income source')) {
        try { await this.transactions.handleSave(date, 'income', true); }
        catch (error) { this.showError(error); }
      }
      this.serviceHub.finishIncomeSetup(date);
    }
    this.terminal.print('\nStarter monthly budgets: 50% Needs, 30% Wants, 20% Savings; edit under Budgets.');
    this.budgets.render(date);
    this.terminal.print('These are editable targets. Fun/entertainment belongs under Wants.');
    while (await this.terminal.yes('Add a regular expense')) {
      try { await this.transactions.handleSave(date, 'expense', true); }
      catch (error) { this.showError(error); }
    }
    this.serviceHub.finishSetup();
    this.terminal.print('Setup saved. You can add more income, expenses and categories from the menus.');
  }

  async run() {
    this.terminal.print('BUDGETBUDDY VERSION 2 | Views -> Controllers -> ServiceHub -> Services');
    if (!this.serviceHub.setupState().complete) await this.setup(today());
    while (true) {
      const date = today();
      const recorded = this.serviceHub.refresh(date);
      if (recorded) this.terminal.print('Automatically recorded ' + recorded + ' due transaction(s).');
      const choice = await this.terminal.mainMenu();
      if (choice === '0') { this.serviceHub.save(); this.terminal.print('Saved. Goodbye!'); return; }
      try {
        if (choice === '1') {
          this.terminal.showOverview(this.serviceHub.getDashboard(date), date);
          this.budgets.render(date);
        }
        if (choice === '2') await this.transactions.open(date);
        if (choice === '3') await this.recurring.open(date);
        if (choice === '4') await this.budgets.open(date);
        if (choice === '5') await this.affordability.handleCheckClicked(date);
        if (choice === '6') await this.challenges.open(date);
      } catch (error) { this.showError(error); }
    }
  }
}
