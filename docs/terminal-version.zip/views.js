import { today, parseDate, validAmount, money } from './helpers.js';

// Views only collect input and display data supplied by controllers.
export class TerminalView {
  constructor(reader) {
    this.lines = reader[Symbol.asyncIterator]();
  }

  print(message) { console.log(message); }

  async ask(prompt) {
    process.stdout.write(prompt);
    const line = await this.lines.next();
    if (line.done) throw new Error('Input closed.');
    return line.value.trim();
  }

  async choose(prompt, options) {
    while (true) {
      const answer = await this.ask(prompt);
      if (options.includes(answer)) return answer;
      this.print('Choose one of: ' + options.join(', '));
    }
  }

  async yes(prompt) {
    return (await this.choose(prompt + ' [y/n]: ', ['y', 'n'])) === 'y';
  }

  async name(prompt) {
    while (true) {
      const answer = await this.ask(prompt);
      if (answer) return answer;
      this.print('Please enter a name.');
    }
  }

  async amount(prompt, allowZero = false) {
    while (true) {
      const text = await this.ask(prompt + ' $');
      if (/^\d+(\.\d{1,2})?$/.test(text)) {
        const cents = Math.round(Number(text) * 100);
        try { validAmount(cents, allowZero); return cents; } catch { /* ask again */ }
      }
      this.print('Enter dollars and cents, such as 1250 or 12.50.');
    }
  }

  async date(prompt) {
    while (true) {
      const answer = await this.ask(prompt + ' [YYYY-MM-DD; Enter = today]: ');
      try { parseDate(answer || today()); return answer || today(); }
      catch (error) { this.print(error.message); }
    }
  }

  async select(items, label, describe) {
    if (!items.length) { this.print('No ' + label + ' available.'); return null; }
    items.forEach((item, index) => this.print((index + 1) + '. ' + describe(item)));
    const options = ['0'];
    for (let index = 0; index < items.length; index++) options.push(String(index + 1));
    const answer = await this.choose('Select ' + label + ' (0 = cancel): ', options);
    return answer === '0' ? null : items[Number(answer) - 1];
  }

  async mainMenu() {
    this.print('\n1. Overview\n2. Transactions\n3. Recurring Items\n4. Budgets\n5. Affordability\n6. Challenges\n0. Save and exit');
    return this.choose('Choose: ', ['0', '1', '2', '3', '4', '5', '6']);
  }

  showOverview(data, date) {
    this.print('\nOVERVIEW | ' + date);
    this.print('Estimated monthly income: ' + money(data.income));
    this.print('Recorded spending this month: ' + money(data.spent));
    this.print('Upcoming expenses this month: ' + money(data.bills));
    this.print('10% income buffer: ' + money(data.buffer));
    this.print('Safe to spend: ' + money(data.safe));
    this.print('This is a monthly estimate, not a bank balance.');
    if (data.overAllocated) this.print('Your category budgets exceed estimated income. Review Budgets.');
    this.print('Savings is a target; affordability reserves only its original 10% buffer.');
  }
}

export class TransactionView {
  constructor(terminal) { this.terminal = terminal; }

  async readAction() {
    this.terminal.print('\nTRANSACTIONS\n1. Add  2. Delete  3. List  0. Back');
    return this.terminal.choose('Choose: ', ['0', '1', '2', '3']);
  }

  describe(item) {
    return item.date + ' | ' + item.type + ' | ' + item.name + ' | ' + money(item.amount) +
      (item.categoryName ? ' | ' + item.categoryName : '') + (item.recurring ? ' | Recurring' : '');
  }

  showList(items) {
    if (!items.length) this.terminal.print('No transactions yet.');
    for (const item of items) this.terminal.print(this.describe(item));
  }

  async selectTransaction(items) {
    return this.terminal.select(items, 'transaction', item => this.describe(item));
  }

  async readInput(categories, type = '', alwaysRecurring = false) {
    const terminal = this.terminal;
    if (!type) {
      const choice = await terminal.choose('1. Income  2. Expense: ', ['1', '2']);
      type = choice === '1' ? 'income' : 'expense';
    }
    const name = await terminal.name('Name: ');
    const amount = await terminal.amount('Amount per payment');
    const date = await terminal.date(alwaysRecurring ? 'First scheduled date' : 'Transaction / first scheduled date');
    let categoryId = '';
    if (type === 'expense') {
      const category = await terminal.select(categories, 'category', c => c.name + ' | ' + money(c.amount));
      if (!category) throw new Error('Cancelled: an expense needs a category.');
      categoryId = category.id;
    }
    const repeating = alwaysRecurring || await terminal.yes('Does this repeat');
    let frequency = '';
    let days = [];
    if (repeating) {
      terminal.print('1. Monthly  2. Every two weeks (14 days)  3. Selected days each month');
      const choice = await terminal.choose('Frequency: ', ['1', '2', '3']);
      frequency = { '1': 'monthly', '2': 'biweekly', '3': 'days' }[choice];
      if (frequency === 'days') {
        while (true) {
          const text = await terminal.ask('Days of month, separated by commas (example 1,15): ');
          if (/^\d{1,2}(\s*,\s*\d{1,2})*$/.test(text)) {
            days = text.split(',').map(Number);
            if (days.every(day => day >= 1 && day <= 31)) break;
          }
          terminal.print('Enter valid days from 1 to 31.');
        }
      }
    }
    return { type, name, amount, date, startDate: date, categoryId, repeating, frequency, days };
  }

  showSaved(result) {
    this.terminal.print(result.repeating ? 'Recurring rule added. Due transactions recorded: ' + result.recorded :
      'One-time transaction added.');
  }
}

export class CalendarView {
  constructor(terminal) { this.terminal = terminal; }

  async readAction(items) {
    this.terminal.print('\nRECURRING ITEMS');
    for (const item of items) {
      this.terminal.print(item.name + ' | ' + item.type + ' | ' + money(item.amount) +
        ' | ' + item.frequency + (item.frequency === 'days' ? ' ' + item.days.join(',') : '') +
        (item.active ? ' | next ' + item.nextDate : ' | stopped'));
    }
    this.terminal.print('1. Add  2. Stop future repeats  3. Change future amount  0. Back');
    return this.terminal.choose('Choose: ', ['0', '1', '2', '3']);
  }

  async selectRule(items) {
    return this.terminal.select(items.filter(item => item.active), 'recurring item', item => item.name);
  }
}

export class BudgetView {
  constructor(terminal) { this.terminal = terminal; }

  render(items) {
    for (const item of items) {
      this.terminal.print(item.name + ': ' + money(item.amount) + ' | spent ' + money(item.spent) +
        (item.flexible ? ' | challenge eligible after 28 days' : ' | protected from challenges'));
    }
  }

  async readInput(items) {
    this.terminal.print('\nMONTHLY BUDGETS');
    this.render(items);
    this.terminal.print('1. Add category  2. Edit budget / challenge eligibility  0. Back');
    const choice = await this.terminal.choose('Choose: ', ['0', '1', '2']);
    if (choice === '0') return null;
    let id = '';
    let name = '';
    if (choice === '1') name = await this.terminal.name('Category name: ');
    else {
      const category = await this.terminal.select(items, 'category', c => c.name);
      if (!category) return null;
      id = category.id;
    }
    const amount = await this.terminal.amount('Monthly budget', true);
    const flexible = await this.terminal.yes('Allow budget-reduction recommendations for this category');
    return { id, name, amount, flexible };
  }
}

export class AffordabilityView {
  constructor(terminal) { this.terminal = terminal; }

  async readInput(categories) {
    this.terminal.print('\nCAN I AFFORD THIS?');
    const price = await this.terminal.amount('Purchase price');
    this.terminal.print('Select a category, or 0 for Any category.');
    const category = await this.terminal.select(categories, 'category', c => c.name + ' | ' + money(c.amount));
    return { price, categoryId: category?.id || '' };
  }

  showResult(result) {
    const terminal = this.terminal;
    if (result.answer === 'yes') {
      terminal.print('Yes, you can afford it. Safe money after purchase: ' + money(result.remaining));
    } else if (result.answer === 'tight') {
      terminal.print('You can, but it is tight. ' + result.reason);
      if (result.categoryRemaining !== undefined) {
        terminal.print('Category remaining before purchase: ' + money(result.categoryRemaining));
      }
    } else {
      terminal.print('Not yet. You are ' + money(result.shortfall) + ' short.');
      terminal.print('Save ' + money(result.weeklySaving4) + '/week for 4 weeks, or ' +
        money(result.weeklySaving8) + '/week for 8 weeks.');
      terminal.print('Open the separate Challenges menu to review any budget recommendations.');
    }
    const numbers = result.numbers;
    terminal.print(money(numbers.left) + ' left - ' + money(numbers.bills) + ' bills - ' +
      money(numbers.buffer) + ' buffer = ' + money(numbers.safe) + ' safe to spend.');
    terminal.print('The check alone does not record a purchase. You can record an actual purchase below.');
  }

  async readExpenseInput(input, categories) {
    if (!await this.terminal.yes('Record this purchase as an expense for today')) return null;
    let categoryId = input.categoryId;
    if (!categoryId) {
      this.terminal.print('A recorded expense needs a category.');
      const category = await this.terminal.select(categories, 'category', c => c.name);
      if (!category) {
        this.terminal.print('Purchase not recorded.');
        return null;
      }
      categoryId = category.id;
    }
    const name = await this.terminal.name('Purchase description: ');
    return { name, categoryId };
  }

  showExpenseSaved(expense) {
    this.terminal.print('Expense recorded: ' + expense.name + ' | ' + money(expense.amount) +
      '. Totals updated.');
  }
}

export class ChallengesView {
  constructor(terminal) { this.terminal = terminal; }

  async readInput(data) {
    this.terminal.print('\nCHALLENGES: BUDGET RECOMMENDATIONS');
    if (data.daysRemaining > 0) {
      this.terminal.print('Recommendations need 28 days of tracking. ' + data.daysRemaining + ' days remaining.');
      return null;
    }
    const idea = await this.terminal.select(data.ideas, 'recommendation', item =>
      item.categoryName + ': ' + money(item.current) + ' -> ' + money(item.recommended) +
      '/month (last 28 days: ' + money(item.spent) + ')');
    if (!idea) return null;
    this.terminal.print('Uses last 28 days / 28 x days in this month. Accept changes the budget only.');
    const action = await this.terminal.choose('a = accept, d = deny, 0 = back: ', ['a', 'd', '0']);
    return action === '0' ? null : { idea, accept: action === 'a' };
  }

  showResult(accepted) {
    this.terminal.print(accepted ? 'Budget updated.' : 'Recommendation dismissed.');
  }
}
