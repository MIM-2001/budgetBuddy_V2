import { MonthlyIncomeCalculator, MonthlyExpenseCalculator, SpendingService,
  RecurringService, AffordabilityService } from './services.js';
import { ChallengesService } from './challenges.js';
import { daysBetween } from './helpers.js';

// Facade: controllers use this one entry point instead of reaching into models.
export class ServiceHub {
  constructor(account, calendar, storage = null) {
    this.account = account;
    this.calendar = calendar;
    this.storage = storage;
    this.incomeCalculator = new MonthlyIncomeCalculator(account, calendar);
    this.expenseCalculator = new MonthlyExpenseCalculator(account);
    this.spendingService = new SpendingService(account, this.incomeCalculator, this.expenseCalculator);
    this.recurringService = new RecurringService(account, calendar);
    this.affordabilityService = new AffordabilityService(this.spendingService, this.recurringService);
    this.challengesService = new ChallengesService(account);
  }

  canAfford(price, categoryId, date) {
    return this.affordabilityService.evaluatePurchase(price, categoryId, date);
  }

  refresh(date) {
    const count = this.recurringService.recordDue(date);
    this.save();
    return count;
  }

  save() {
    if (this.storage) this.storage.save(this.account, this.calendar);
  }

  setupState() {
    return { complete: this.account.setupComplete, stage: this.account.setupStage };
  }

  finishIncomeSetup(date) {
    if (this.account.categories.length === 0) this.account.createStarterBudgets(this.calendar, date);
    this.account.setupStage = 'expenses';
    this.save();
  }

  finishSetup() {
    this.account.setupComplete = true;
    this.account.setupStage = 'complete';
    this.save();
  }

  getBudgets(date) {
    return this.account.categories.map(category => ({
      id: category.id, name: category.name, amount: category.amount, flexible: category.flexible,
      spent: this.expenseCalculator.forBudget(category.id, date)
    }));
  }

  saveBudget(item, date) {
    if (item.id) {
      const category = this.account.getCategory(item.id);
      category.setBudget(item.amount);
      category.flexible = item.flexible;
    } else this.account.addCategory(item.name, item.amount, item.flexible, date);
    this.save();
  }

  getTransactions() {
    return this.account.transactions.map(transaction => ({
      id: transaction.id, date: transaction.date, name: transaction.name,
      amount: transaction.amount, type: transaction.type, recurring: Boolean(transaction.recurringId),
      categoryName: transaction.categoryId ? this.account.getCategory(transaction.categoryId).name : ''
    })).reverse().sort((a, b) => b.date.localeCompare(a.date));
  }

  saveTransaction(item, date) {
    let recorded = 0;
    if (item.repeating) recorded = this.recurringService.add(item, date);
    else this.account.addTransaction(item, date);
    this.save();
    return { repeating: item.repeating, recorded };
  }

  deleteTransaction(id) {
    this.account.deleteTransaction(id);
    this.save();
  }

  getRecurringItems() {
    return this.calendar.rules.map(rule => ({
      id: rule.id, name: rule.name, type: rule.type, amount: rule.amount,
      frequency: rule.frequency, days: rule.days.slice(), nextDate: rule.nextDate, active: rule.active
    }));
  }

  stopRecurring(id) {
    this.recurringService.stop(id);
    this.save();
  }

  changeRecurringAmount(id, amount) {
    this.recurringService.changeAmount(id, amount);
    this.save();
  }

  getDashboard(date) {
    const numbers = this.affordabilityService.getSafeToSpend(date);
    const budgets = this.getBudgets(date);
    const allocated = budgets.reduce((total, category) => total + category.amount, 0);
    return { ...numbers, spent: this.expenseCalculator.calculate(date), budgets,
      overAllocated: allocated > numbers.income };
  }

  getChallenges(date) {
    const daysRemaining = Math.max(0, 28 - daysBetween(this.account.historyStart, date));
    const ideas = this.challengesService.suggest(date).map(idea => ({ ...idea,
      categoryName: this.account.getCategory(idea.categoryId).name }));
    return { daysRemaining, ideas };
  }

  respondToChallenge(idea, accept, date) {
    if (accept) this.challengesService.accept(idea, date);
    else this.challengesService.deny(idea, date);
    this.save();
  }
}
